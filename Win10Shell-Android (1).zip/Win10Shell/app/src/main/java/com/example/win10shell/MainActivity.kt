package com.example.win10shell

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Two web views stacked in one screen:
 *  - shell:   the Windows 10 desktop page (assets/index.html)
 *  - browser: a real browser view that the desktop's Edge window positions on top of itself.
 */
class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var shell: WebView
    private lateinit var browserView: WebView
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var defUa = ""

    private val dlDir: File get() = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)!!

    private fun js(code: String) = runOnUiThread { shell.evaluateJavascript(code, null) }
    private fun toast(msg: String) = js("toast(${JSONObject.quote(msg)})")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()

        shell = WebView(this)
        shell.settings.javaScriptEnabled = true
        shell.settings.domStorageEnabled = true
        shell.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                if (r.url.host == "appassets.androidplatform.net") loader.shouldInterceptRequest(r.url) else null
        }
        shell.addJavascriptInterface(Bridge(), "Native")

        val b = WebView(this)
        browserView = b
        b.visibility = View.GONE
        b.settings.javaScriptEnabled = true
        b.settings.domStorageEnabled = true
        b.settings.setSupportMultipleWindows(true)
        b.settings.javaScriptCanOpenWindowsAutomatically = true
        b.settings.mediaPlaybackRequiresUserGesture = false
        b.settings.userAgentString = b.settings.userAgentString.replace("; wv", "")
        defUa = b.settings.userAgentString
        CookieManager.getInstance().setAcceptThirdPartyCookies(b, true)

        b.webViewClient = object : WebViewClient() {
            override fun onPageStarted(v: WebView, url: String, f: android.graphics.Bitmap?) {
                js("window.edgeUrl&&edgeUrl(${JSONObject.quote(url)})")
            }
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val s = r.url.scheme
                if (s == "http" || s == "https") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) {}
                return true
            }
        }
        b.webChromeClient = object : WebChromeClient() {
            // Links that open a new window/tab are shown in the same browser view.
            override fun onCreateWindow(v: WebView, dialog: Boolean, gesture: Boolean, msg: Message): Boolean {
                val t = WebView(this@MainActivity)
                t.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v2: WebView, r: WebResourceRequest): Boolean {
                        browserView.loadUrl(r.url.toString()); return true
                    }
                }
                (msg.obj as WebView.WebViewTransport).webView = t
                msg.sendToTarget()
                return true
            }
            // Full-screen video (YouTube).
            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                customView = view; customCb = cb
                root.addView(view, FrameLayout.LayoutParams(-1, -1))
            }
            override fun onHideCustomView() {
                customView?.let { root.removeView(it) }
                customView = null; customCb?.onCustomViewHidden()
            }
        }
        // Downloads land in the desktop's Downloads folder (File Explorer > Downloads).
        b.setDownloadListener { url, ua, cd, mime, _ ->
            startDownload(url, ua, cd, mime, b.url ?: url)
        }

        root.addView(shell, FrameLayout.LayoutParams(-1, -1))
        root.addView(b, FrameLayout.LayoutParams(1, 1))
        setContentView(root)
        shell.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun origin(u: String?): String? = try {
        val p = Uri.parse(u)
        if (p.host != null) "${p.scheme}://${p.host}/" else null
    } catch (e: Exception) { null }

    // Opens the file URL like a browser would (same cookies, user agent and Referer), following redirects.
    private fun connect(start: String, ua: String, ref: String): HttpURLConnection? {
        var u = start
        for (n in 1..6) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 20000
            c.readTimeout = 30000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", ua)
            c.setRequestProperty("Referer", ref)
            c.setRequestProperty("Accept", "*/*")
            val cookie = CookieManager.getInstance().getCookie(u)
            if (cookie != null) c.setRequestProperty("Cookie", cookie)
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: return null
                u = URL(URL(u), loc).toString()
                c.disconnect()
            } else {
                return c
            }
        }
        return null
    }

    // If a site answers with a "hotlink protection" page instead of the file, retry with other Referer values.
    private fun startDownload(url: String, ua: String?, cd: String?, mime: String?, page: String?) {
        val name = File(URLUtil.guessFileName(url, cd, mime)).name
        toast("\u2b07 Downloading $name \u2026")
        Thread {
            try {
                val refs = listOfNotNull(page, origin(page), origin(url), url).distinct()
                val wantHtml = mime != null && mime.startsWith("text/html")
                var ok = false
                for (ref in refs) {
                    val c = connect(url, ua ?: defUa, ref) ?: continue
                    val ct = c.contentType ?: ""
                    if (c.responseCode in 200..299 && (wantHtml || !ct.startsWith("text/html"))) {
                        val part = File(dlDir, "$name.part")
                        c.inputStream.use { i -> part.outputStream().use { o -> i.copyTo(o) } }
                        part.renameTo(File(dlDir, name))
                        ok = true
                        break
                    }
                    c.disconnect()
                }
                toast(
                    if (ok) "\u2705 $name saved to Downloads"
                    else "The site blocked this download (hotlink protection). Open its original page and use the download button there."
                )
            } catch (e: Exception) {
                toast("Download failed: $name")
            }
        }.start()
    }

    inner class Bridge {
        @JavascriptInterface
        fun browser(vis: Boolean, x: Double, y: Double, w: Double, h: Double) {
            runOnUiThread {
                val v = this@MainActivity.browserView
                if (!vis || w < 2 || h < 2) {
                    v.visibility = View.GONE
                } else {
                    val d = resources.displayMetrics.density
                    val lp = FrameLayout.LayoutParams((w * d).toInt(), (h * d).toInt())
                    lp.leftMargin = (x * d).toInt()
                    lp.topMargin = (y * d).toInt()
                    v.layoutParams = lp
                    v.visibility = View.VISIBLE
                }
            }
        }

        @JavascriptInterface fun go(u: String) { runOnUiThread { browserView.loadUrl(u) } }
        @JavascriptInterface fun reload() { runOnUiThread { browserView.reload() } }
        @JavascriptInterface fun back(): Boolean = nav(true)
        @JavascriptInterface fun fwd(): Boolean = nav(false)

        private fun nav(back: Boolean): Boolean {
            var ok = false
            val l = CountDownLatch(1)
            runOnUiThread {
                ok = if (back) browserView.canGoBack() else browserView.canGoForward()
                if (ok) { if (back) browserView.goBack() else browserView.goForward() }
                l.countDown()
            }
            l.await(1, TimeUnit.SECONDS)
            return ok
        }

        @JavascriptInterface
        fun download(u: String) {
            val h = Uri.parse(u)
            startDownload(u, null, null, null, "${h.scheme}://${h.host}/")
        }

        // Apps installed on the tablet, shown in the desktop's Start menu.
        @JavascriptInterface
        fun listApps(): String {
            val a = JSONArray()
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val pm = packageManager
            pm.queryIntentActivities(i, 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach {
                    a.put(JSONObject().put("pkg", it.activityInfo.packageName).put("name", it.loadLabel(pm).toString()))
                }
            return a.toString()
        }

        @JavascriptInterface
        fun launch(pkg: String) {
            runOnUiThread {
                val i = packageManager.getLaunchIntentForPackage(pkg)
                if (i != null) startActivity(i)
            }
        }

        @JavascriptInterface
        fun listDownloads(): String {
            val a = JSONArray()
            val files = (dlDir.listFiles() ?: emptyArray()).filter { it.isFile && !it.name.endsWith(".part") }
            files.sortedBy { it.lastModified() }.forEach {
                a.put(JSONObject().put("name", it.name).put("size", it.length()))
            }
            return a.toString()
        }

        @JavascriptInterface
        fun deleteDownload(name: String) {
            File(dlDir, File(name).name).delete()
        }

        // Tap a download: .apk files start the Android installer; other files open in a matching app.
        @JavascriptInterface
        fun openDownload(name: String) {
            runOnUiThread {
                val f = File(dlDir, File(name).name)
                val ext = f.extension.lowercase()
                val mime = if (ext == "apk") "application/vnd.android.package-archive"
                    else MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
                try {
                    val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.files", f)
                    val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } catch (e: Exception) {
                    toast("No app on this tablet can open ${f.name}")
                }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (customView != null) {
            browserView.webChromeClient?.onHideCustomView()
        } else if (browserView.visibility == View.VISIBLE && browserView.canGoBack()) {
            browserView.goBack()
        }
        // otherwise stay on the desktop, like a launcher
    }
}
