package com.example.win10shell

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.FrameLayout
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Two web views stacked in one screen:
 *  - shell:   the Windows 10 desktop page (assets/index.html)
 *  - browser: a real browser view that the desktop's Edge window positions on top of itself.
 * Because the browser is a normal top-level page, every site works: links, YouTube, logins, downloads.
 */
class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var shell: WebView
    private lateinit var browser: WebView
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    private val dlDir: File get() = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)!!

    private fun js(code: String) = runOnUiThread { shell.evaluateJavascript(code, null) }
    private fun toast(msg: String) = js("toast(${JSONObject.quote(msg)})")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()

        shell = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                    if (r.url.host == "appassets.androidplatform.net") loader.shouldInterceptRequest(r.url) else null
            }
            addJavascriptInterface(Bridge(), "Native")
        }

        browser = WebView(this).apply {
            visibility = View.GONE
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.setSupportMultipleWindows(true)
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.userAgentString = settings.userAgentString.replace("; wv", "")
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

            webViewClient = object : WebViewClient() {
                override fun onPageStarted(v: WebView, url: String, f: android.graphics.Bitmap?) {
                    js("window.edgeUrl&&edgeUrl(${JSONObject.quote(url)})")
                }
                override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                    val s = r.url.scheme
                    if (s == "http" || s == "https") return false
                    try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) {}
                    return true
                }
            }
            webChromeClient = object : WebChromeClient() {
                // Links that open a new window/tab: show them in the same browser view.
                override fun onCreateWindow(v: WebView, dialog: Boolean, gesture: Boolean, msg: Message): Boolean {
                    val t = WebView(this@MainActivity)
                    t.webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(v2: WebView, r: WebResourceRequest): Boolean {
                            browser.loadUrl(r.url.toString()); return true
                        }
                    }
                    (msg.obj as WebView.WebViewTransport).webView = t
                    msg.sendToTarget()
                    return true
                }
                // Full-screen video (YouTube).
                override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                    customView = view; customCb = cb
                    root.addView(view, FrameLayout.LayoutParams(-1, -1))
                }
                override fun onHideCustomView() {
                    customView?.let { root.removeView(it) }
                    customView = null; customCb?.onCustomViewHidden()
                }
            }
            // Downloads land in the desktop's Downloads folder (File Explorer > Downloads).
            setDownloadListener { url, ua, cd, mime, _ ->
                startDownload(url, ua, cd, mime, this.url ?: url)
            }
        }

        root.addView(shell, FrameLayout.LayoutParams(-1, -1))
        root.addView(browser, FrameLayout.LayoutParams(1, 1))
        setContentView(root)
        shell.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    // Downloads land in the desktop's Downloads folder. The Referer header stops "hotlink protection" errors.
    private fun startDownload(url: String, ua: String?, cd: String?, mime: String?, referer: String?) {
        val name = URLUtil.guessFileName(url, cd, mime)
        try {
            val req = DownloadManager.Request(Uri.parse(url))
                .addRequestHeader("User-Agent", ua ?: browser.settings.userAgentString)
                .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                .addRequestHeader("Referer", referer ?: url)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name)
            if (!mime.isNullOrBlank()) req.setMimeType(mime)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("\u2b07 Downloading $name \u2026 it will appear in Downloads")
        } catch (e: Exception) { toast("Download failed: $name") }
    }

    inner class Bridge {
        @JavascriptInterface fun browser(vis: Boolean, x: Double, y: Double, w: Double, h: Double) = runOnUiThread {
            if (!vis || w < 2 || h < 2) { browser.visibility = View.GONE; return@runOnUiThread }
            val d = resources.displayMetrics.density
            val lp = FrameLayout.LayoutParams((w * d).toInt(), (h * d).toInt())
            lp.leftMargin = (x * d).toInt(); lp.topMargin = (y * d).toInt()
            browser.layoutParams = lp
            browser.visibility = View.VISIBLE
        }
        @JavascriptInterface fun go(u: String) = runOnUiThread { browser.loadUrl(u) }
        @JavascriptInterface fun download(u: String) = runOnUiThread {
            val h = Uri.parse(u)
            startDownload(u, null, null, null, "${h.scheme}://${h.host}/")
        }
        @JavascriptInterface fun reload() = runOnUiThread { browser.reload() }
        @JavascriptInterface fun back(): Boolean = nav(true)
        @JavascriptInterface fun fwd(): Boolean = nav(false)

        private fun nav(back: Boolean): Boolean {
            var ok = false
            val l = CountDownLatch(1)
            runOnUiThread {
                ok = if (back) browser.canGoBack() else browser.canGoForward()
                if (ok) { if (back) browser.goBack() else browser.goForward() }
                l.countDown()
            }
            l.await(1, TimeUnit.SECONDS)
            return ok
        }

        @JavascriptInterface fun listDownloads(): String {
            val a = JSONArray()
            (dlDir.listFiles() ?: emptyArray()).filter { it.isFile }.sortedBy { it.lastModified() }.forEach {
                a.put(JSONObject().put("name", it.name).put("size", it.length()))
            }
            return a.toString()
        }

        @JavascriptInterface fun deleteDownload(name: String) { File(dlDir, File(name).name).delete() }

        // Tap a download: .apk files start the Android installer; other files open in a matching app.
        @JavascriptInterface fun openDownload(name: String) = runOnUiThread {
            val f = File(dlDir, File(name).name)
            val ext = f.extension.lowercase()
            val mime = if (ext == "apk") "application/vnd.android.package-archive"
                else MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
            try {
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.files", f)
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) { toast("No app on this tablet can open ${f.name}") }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> browser.webChromeClient?.onHideCustomView()
            browser.visibility == View.VISIBLE && browser.canGoBack() -> browser.goBack()
            else -> { /* stay on the desktop, like a launcher */ }
        }
    }
}
