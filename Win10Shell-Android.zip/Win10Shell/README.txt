1. Install Android Studio on a PC and open this folder (File > Open). Let Gradle sync.
2. Plug in the tablet (USB debugging on) and press Run.
3. To make it the tablet's home screen: Settings > Apps > Default apps > Home app > Win10 Shell.
The desktop page is app/src/main/assets/index.html.
